import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import { v4 as uuidv4 } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { prompt } = req.body;
  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  const sessionId = uuidv4();
  const projectDir = path.join(process.cwd(), 'public', 'projects', sessionId);
  const zipPath = `/projects/${sessionId}.zip`;

  try {
    const apiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: 'You are a helpful AI developer assistant that generates file structures and content.' },
          { role: 'user', content: prompt },
        ],
        temperature: 0.7,
      }),
    });

    const json = await apiRes.json();
    const code = json.choices?.[0]?.message?.content || '';

    fs.mkdirSync(projectDir, { recursive: true });
    fs.writeFileSync(path.join(projectDir, 'main.txt'), code);

    const archive = archiver('zip', { zlib: { level: 9 } });
    const zipOutputPath = path.join(process.cwd(), 'public', 'projects', `${sessionId}.zip`);
    const output = fs.createWriteStream(zipOutputPath);

    archive.pipe(output);
    archive.directory(projectDir, false);
    await archive.finalize();

    res.status(200).json({
      result: code,
      fileTree: { 'main.txt': 'Generated from AI' },
      zipPath,
    });
  } catch (error) {
    res.status(500).json({ error: 'Error generating or saving code.' });
  }
}
