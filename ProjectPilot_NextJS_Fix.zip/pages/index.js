// ProjectPilot: AI-powered Browser-Based Coding Assistant with File Generation & Preview

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function ProjectPilot() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [fileTree, setFileTree] = useState(null);
  const [zipLink, setZipLink] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    setResponse('');
    setFileTree(null);
    setZipLink(null);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      setResponse(data.result || 'No response received.');
      setFileTree(data.fileTree || null);
      setZipLink(data.zipPath || null);
    } catch (err) {
      setResponse('Error generating code.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-4 text-center">ProjectPilot</h1>
      <Card className="max-w-xl mx-auto">
        <CardContent>
          <Input
            placeholder="Describe what you want to build..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="mb-2"
          />
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? 'Generating...' : 'Build'}
          </Button>
          {response && (
            <pre className="mt-4 p-2 bg-black text-green-400 overflow-auto text-sm rounded">
              {response}
            </pre>
          )}
          {fileTree && (
            <div className="mt-4 text-sm bg-white p-2 rounded border">
              <strong>Generated File Structure:</strong>
              <pre>{JSON.stringify(fileTree, null, 2)}</pre>
            </div>
          )}
          {zipLink && (
            <div className="mt-4">
              <a href={zipLink} target="_blank" className="text-blue-600 underline">
                Download Generated Project Zip
              </a>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
