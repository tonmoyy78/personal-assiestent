# ProjectPilot

1. `npm install`
2. Add `.env.local`
3. `npm run dev`